@mainpage Calculator Application by Bharath G
@subpage calculator_operations.h